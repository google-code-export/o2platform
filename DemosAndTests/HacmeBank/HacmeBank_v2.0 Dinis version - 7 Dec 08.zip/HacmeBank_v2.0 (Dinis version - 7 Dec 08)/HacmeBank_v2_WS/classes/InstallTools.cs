using System;
using System.Text.RegularExpressions;

namespace HacmeBank_v2_WS
{
	/// <summary>
	/// Summary description for SolutionConfig.
	/// </summary>
	public class InstallTools
	{
		static string pathTo_SQLServerDatabaseConfigFile = AppDomain.CurrentDomain.BaseDirectory + "//install//FoundStoneBank_export.sql";
		public InstallTools()
		{
			//
			// TODO: Add constructor logic here
			//
		}


	}
}
