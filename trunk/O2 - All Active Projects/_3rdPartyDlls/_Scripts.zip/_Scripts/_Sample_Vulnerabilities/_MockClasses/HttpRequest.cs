namespace O2.XRules.Database._Rules._Sample_Vulnerabilities._MockClasses
{
    public class HttpRequest
    {
        public string this[string key]
        {
            get
            {
                return null;
            }
        }
    }
}