namespace O2.XRules.Database._Rules._Sample_Vulnerabilities._MockClasses
{
    public class SqlCommand
    {
        public SqlCommand(string sql, object o)
        {
            
        }
    }
}