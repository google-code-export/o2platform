// This file is part of the OWASP O2 Platform (http://www.owasp.org/index.php/OWASP_O2_Platform) and is released under the Apache 2.0 License (http://www.apache.org/licenses/LICENSE-2.0)
using System;
using System.IO;
using System.Web;
using System.Security.Principal;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using O2.Kernel;
using O2.Kernel.ExtensionMethods;
using O2.DotNetWrappers.DotNet;
using O2.DotNetWrappers.Windows;
using O2.DotNetWrappers.ExtensionMethods;
using Moq;


//O2Ref:moq.dll
//O2Ref:System.Web.Abstractions.dll
//O2File:_Extra_methods_To_Add_to_Main_CodeBase.cs

namespace O2.XRules.Database.APIs
{
    public class API_Moq_HttpContext 
    {        	
		public Mock<HttpContextBase> MockContext { get; set; }
		public Mock<HttpRequestBase> MockRequest { get; set; }
		public Mock<HttpResponseBase> MockResponse { get; set; }
		public Mock<HttpSessionStateBase> MockSession { get; set; }
		public Mock<HttpServerUtilityBase> MockServer { get; set; }		
		
        public HttpContextBase HttpContextBase  { get; set; }
        public HttpRequestBase HttpRequestBase  { get; set; }
        public HttpResponseBase HttpResponseBase  { get; set; }        
	    
		public API_Moq_HttpContext()
		{
			createBaseMocks();
			setupNormalRequestValues();
		}
		
    	public API_Moq_HttpContext createBaseMocks()
    	{
    		MockContext = new Mock<HttpContextBase>();
	        MockRequest = new Mock<HttpRequestBase>();
	        MockResponse = new Mock<HttpResponseBase>();
	        MockSession = new Mock<HttpSessionStateBase>();
	        MockServer = new Mock<HttpServerUtilityBase>();
	        
	
	        MockContext.Setup(ctx => ctx.Request).Returns(MockRequest.Object);
	        MockContext.Setup(ctx => ctx.Response).Returns(MockResponse.Object);
	        MockContext.Setup(ctx => ctx.Session).Returns(MockSession.Object);
	        MockContext.Setup(ctx => ctx.Server).Returns(MockServer.Object);
	        
	     	
	     	HttpContextBase = MockContext.Object; 
	     	HttpRequestBase = MockRequest.Object;
	     	HttpResponseBase = MockResponse.Object;
	     		     	
	     	return this;
		}
		
		public API_Moq_HttpContext setupNormalRequestValues()
		{
			//Context.User
			//var MockUser = new Mock<IPrincipal>();
	        //var MockIdentity = new Mock<IIdentity>();		
	        
	        var genericIdentity = new GenericIdentity("genericIdentity");
	        var genericPrincipal = new GenericPrincipal(genericIdentity, new string[] {});
			MockContext.Setup(context => context.User).Returns(genericPrincipal);	     	
	     	
	     	//Request
	     	MockRequest.Setup(request =>request.InputStream).Returns(new MemoryStream()); 
	     	
	     	//Response
	     	MockResponse.Setup(response =>response.OutputStream).Returns(new MemoryStream()); 
	     	return this;
		}
	}
	
	public static class API_Moq_HttpContext_ExtensionMethods
	{
		public static HttpContextBase httpContext(this API_Moq_HttpContext moqHttpContext)
		{
			return moqHttpContext.HttpContextBase;
		}
		
		public static HttpContextBase request_Write_Clear(this API_Moq_HttpContext moqHttpContext)
		{
			moqHttpContext.MockRequest.Setup(request =>request.InputStream).Returns(new MemoryStream()); 
			
			return moqHttpContext.httpContext();
		}
		
		public static HttpContextBase request_Write(this HttpContextBase httpContextBase,string text)
		{														
			httpContextBase.stream_Write(httpContextBase.Request.InputStream, text);			
			return httpContextBase;
		}
		
		public static string request_Read(this HttpContextBase httpContextBase)
		{					
			return httpContextBase.stream_Read(httpContextBase.Request.InputStream);
		}
		
		public static HttpContextBase response_Write(this HttpContextBase httpContextBase,string text)
		{														
			httpContextBase.stream_Write(httpContextBase.Response.OutputStream, text);			
			return httpContextBase;
		}
		
		public static string response_Read(this HttpContextBase httpContextBase)
		{					
			return httpContextBase.stream_Read(httpContextBase.Response.OutputStream);						
		}
		
		public static HttpContextBase stream_Write(this HttpContextBase httpContextBase, Stream inputStream, string text)
		{														
			var streamWriter = new StreamWriter(inputStream);
			
			inputStream.Position = inputStream.property("Length").str().toInt(); 
			streamWriter.Write(text);    
			streamWriter.Flush(); 			
			inputStream.Position = 0; 			
			
			return httpContextBase;
		}
		
		public static string stream_Read(this HttpContextBase httpContextBase, Stream inputStream)
		{								
			var originalPosition = inputStream.Position;
			var streamReader = new StreamReader(inputStream);
			var requestData = streamReader.ReadToEnd();	
			inputStream.Position = originalPosition;
			return requestData;
		}
	}
}        
