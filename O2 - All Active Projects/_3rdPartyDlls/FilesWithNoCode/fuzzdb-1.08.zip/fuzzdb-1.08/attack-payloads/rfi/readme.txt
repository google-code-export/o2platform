Other tools:

fimap http://code.google.com/p/fimap/
