other tools:

fimap http://code.google.com/p/fimap/
