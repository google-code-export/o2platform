# files generated with cms-explorer
http://code.google.com/p/cms-explorer/
use these for q&d but cms explorer does a lot more
