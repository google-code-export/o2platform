//O2File:HttpRequest.cs

namespace O2.XRules.Database._Rules._Sample_Vulnerabilities._MockClasses
{
    public class HttpContext
    {
        public static HttpContext Current;

        public HttpRequest Request;
    }
}